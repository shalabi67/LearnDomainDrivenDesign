﻿using DddInPractice.Logic.Common;

namespace DddInPractice.Logic.SnackMachines
{
    public class SnackMachineRepository : Repository<SnackMachine>
    {
    }
}
