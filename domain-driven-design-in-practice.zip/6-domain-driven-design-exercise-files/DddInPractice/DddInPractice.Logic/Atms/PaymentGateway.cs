﻿namespace DddInPractice.Logic.Atms
{
    public class PaymentGateway
    {
        public void ChargePayment(decimal amount)
        {
        }
    }
}
