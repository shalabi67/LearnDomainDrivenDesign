﻿namespace DddInPractice.Logic.Common
{
    public abstract class AggregateRoot : Entity
    {
    }
}
